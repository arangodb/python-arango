'use strict';

module.context.use('/test', require('./routes/test'), 'test');
